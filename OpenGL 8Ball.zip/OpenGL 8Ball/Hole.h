#pragma once
#include "Wall.h"

class Hole:public Wall
{
public:
	Hole();
	~Hole();
	using Wall::Draw;
	using Wall::WallGeometry;
	void WallGeometry();
	
	void Draw()
	{
		glDepthMask(GL_FALSE);

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		glPushMatrix();				
		WallGeometry();
		glPopMatrix();

		glDisable(GL_BLEND);
		glDepthMask(GL_TRUE);
	}
private:

};

Hole::Hole()
{

}

void Hole::WallGeometry()
{
	glTranslatef(position.x, position.y, position.z);
	// top
	glBegin(GL_QUADS);
	glColor4f(0.8f, 0.2f, 0.5f, 0.4f);
	glNormal3f(0.0f, 1.0f, 0.0f);
	glVertex3f(-l1, l2, l3);
	glVertex3f(l1, l2, l3);
	glVertex3f(l1, l2, -l3);
	glVertex3f(-l1, l2, -l3);

	// front
	glNormal3f(0.0f, 0.0f, 1.0f);
	glVertex3f(l1, -l2, l3);
	glVertex3f(l1, l2, l3);
	glVertex3f(-l1, l2, l3);
	glVertex3f(-l1, -l2, l3);

	// right
	glNormal3f(1.0f, 0.0f, 0.0f);
	glVertex3f(l1, l2, -l3);
	glVertex3f(l1, l2, l3);
	glVertex3f(l1, -l2, l3);
	glVertex3f(l1, -l2, -l3);

	// left
	glNormal3f(-1.0f, 0.0f, 0.0f);
	glVertex3f(-l1, -l2, l3);
	glVertex3f(-l1, l2, l3);
	glVertex3f(-l1, l2, -l3);
	glVertex3f(-l1, -l2, -l3);

	// bottom
	glNormal3f(0.0f, -1.0f, 0.0f);
	glVertex3f(l1, -l2, l3);
	glVertex3f(-l1, -l2, l3);
	glVertex3f(-l1, -l2, -l3);
	glVertex3f(l1, -l2, -l3);

	// back
	glNormal3f(0.0f, 0.0f, -1.0f);
	glVertex3f(l1, l2, -l3);
	glVertex3f(l1, -l2, -l3);
	glVertex3f(-l1, -l2, -l3);
	glVertex3f(-l1, l2, -l3);
	glEnd();
}

Hole::~Hole()
{
}