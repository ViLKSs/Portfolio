#pragma once
#include "Vector3.h"

class Wall
{
public:
	Wall();
	Wall(float w, float h, float o, Vector3 pos, int i, int _textureNumber) : width(w), height(h), other(o), position(pos), id(i)
	{
		l1 = w / 2.0f; l2 = h / 2.0f; l3 = o / 2.0f;
		tNumber = _textureNumber;
		LoadWall();
		CreateWall();
	}
	void setProperties(float w, float h, float o, Vector3 pos, float _r, float _g, float _b, int i)
	{
		width = w;
		height = h;
		other = o;
		position = pos;
		r = _r;
		g = _g;
		b = _b;
		l1 = w / 2.0f; l2 = h / 2.0f; l3 = o / 2.0f;

		CreateWall();
	}
	void LoadWall();
	void Draw();
	void CreateWall();
	void WallGeometry();
	~Wall();

	int id;
	int tNumber;
	float width, height, other;
	Vector3 position;
	Vector3 front;
	float l1, l2, l3;
	tgaInfo *im;
	GLuint texture2;
private:
	float r, g, b;
};

Wall::Wall()
{
	width = 2.0f;
	height = 2.0f;
	position = Vector3(0, 0, 0);
	front = Vector3(1, 0, 0);
}
void Wall::CreateWall()
{

	WallGeometry();

}
void Wall::Draw()
{
	glPushMatrix();
	WallGeometry();
	glPopMatrix();
}

void Wall::LoadWall()
{
	char impathfile[255] = "";

	std::string path = "Table/t" + std::to_string(tNumber) + ".tga";
	strcpy(impathfile, path.c_str());

	// Carrega a imagem de textura
	im = tgaLoad(impathfile);
	
	glEnable(GL_TEXTURE_2D);

	glGenTextures(1, &texture2);

	glBindTexture(GL_TEXTURE_2D, texture2);

	// Cria o objeto quadric e ativa o FILL para desenho desse objeto
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); // MIPMAP
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	//gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGB, im->width, im->height, GL_RGB, GL_UNSIGNED_BYTE, im->imageData); // MIPMAP
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, im->width, im->height, 0, GL_RGB, GL_UNSIGNED_BYTE, im->imageData);

	// Destr�i a imagem
	tgaDestroy(im);
}

void Wall::WallGeometry()
{
	glTranslatef(position.x, position.y, position.z);

	glColor4f(1.0, 1.0, 1.0, 1.0);

	glBindTexture(GL_TEXTURE_2D, texture2);

	GLfloat colorWhite[] = { 1.0,1.0,1.0,1.0 };
	GLfloat specReflection[] = { 0.8f,0.8f,0.8f,1.0 };

	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, colorWhite);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specReflection);
	glMateriali(GL_FRONT_AND_BACK, GL_SHININESS, 128);

	glBegin(GL_QUADS);	
	//top
	//glColor3f(r, g, b);
	glNormal3f(0.0f, -1.0f, 0.0f);
	glTexCoord2f(0, 0);
	glVertex3f(-l1, l2, l3); 
	glTexCoord2f(1, 0);
	glVertex3f(l1, l2, l3);
	glTexCoord2f(1, 1);
	glVertex3f(l1, l2, -l3); 
	glTexCoord2f(0, 1);
	glVertex3f(-l1, l2, -l3); 

	// front
	//glColor3f(0.0f, 1.0f, 0.0f);
	glNormal3f(0.0f, 0.0f, 1.0f);
	glTexCoord2f(0, 1);
	glVertex3f(l1, -l2, l3); 
	glTexCoord2f(1, 1);
	glVertex3f(l1, l2, l3); 
	glTexCoord2f(1, 0);
	glVertex3f(-l1, l2, l3); 
	glTexCoord2f(0, 0);
	glVertex3f(-l1, -l2, l3); 

	// right
	//glColor3f(0.01f, 0.0f, 1.0f);
	glNormal3f(1.0f, 0.0f, 0.0f);
	glTexCoord2f(1, 1);
	glVertex3f(l1, l2, -l3);
	glTexCoord2f(0, 1);
	glVertex3f(l1, l2, l3); 
	glTexCoord2f(0, 0);
	glVertex3f(l1, -l2, l3); 
	glTexCoord2f(1, 0);
	glVertex3f(l1, -l2, -l3); 

	// left
	//glColor3f(0.0f, 0.0f, 0.5f);
	glNormal3f(-1.0f, 0.0f, 0.0f);
	glTexCoord2f(1, 0);
	glVertex3f(-l1, -l2, l3);
	glTexCoord2f(1, 1);
	glVertex3f(-l1, l2, l3);
	glTexCoord2f(0, 1);
	glVertex3f(-l1, l2, -l3);
	glTexCoord2f(0, 0);
	glVertex3f(-l1, -l2, -l3);

	// bottom
	//glColor3f(0.5f, 0.0f, 0.0f);
	glNormal3f(0.0f, -1.0f, 0.0f);
	glTexCoord2f(1, 1);
	glVertex3f(l1, -l2, l3);
	glTexCoord2f(0, 1);
	glVertex3f(-l1, -l2, l3); 
	glTexCoord2f(0, 0);
	glVertex3f(-l1, -l2, -l3);
	glTexCoord2f(1, 0);
	glVertex3f(l1, -l2, -l3);

	// back
	//glColor3f(0.0f, 0.5f, 0.0f);
	glNormal3f(0.0f, 0.0f, -1.0f);
	glTexCoord2f(0, 0);
	glVertex3f(l1, l2, -l3);
	glTexCoord2f(0, 1);
	glVertex3f(l1, -l2, -l3);
	glTexCoord2f(1, 0);
	glVertex3f(-l1, -l2, -l3);
	glTexCoord2f(1, 1);
	glVertex3f(-l1, l2, -l3);
	glEnd();
}

Wall::~Wall()
{
}