#pragma once

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include "Camera.h"
#include "SubWindow.h"

namespace gameengine {

	class MainWindow {
	public:
		MainWindow(int x, int y, int width, int height, std::string windowName = "");
		int AddSubWindow(int ParentId, int x, int y, int width, int height, std::string windowName);
		~MainWindow();

		int windowId;
		Camera camera;
		std::vector<SubWindow> gameSubWindows;
		int x, y, screenWidth, screenHeight;

	private:
		static int countWindows;
		std::string windowName;
	};
}