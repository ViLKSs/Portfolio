#include <iostream>
#include <gl/freeglut.h>
#include "Ball.h" 
#include "glm.h"
#include "stdlib.h"
#include <string>
#include <sstream>


Ball::Ball()
{
	pos = Vector3(0,0,0);
}

Ball::Ball(float r, float g, float b, float x, float y, float z, float raio, int number) :
	red(r), green(g), blue(b), pos(x, y, z), raio(raio), Number(number) {
	pos.y = raio;
	bagged = false;
	LoadBall(number);
}

void Ball::LoadBall(int number)
{
	char impathfile[255] = "";

	if (number == 0)
	{	
		std::string path = "BallsTexture/BallCue.tga";
		strcpy(impathfile, path.c_str());
	}
	else if (number != 0)
	{
		std::string path = "BallsTexture/Ball" + std::to_string(number) + ".tga";
		strcpy(impathfile, path.c_str());
	}
	
	// Carrega a imagem de textura
	im = tgaLoad(impathfile);

	printf("IMAGE INFO: %s\nstatus: %d\ntype: %d\npixelDepth: %d\nsize%d x %d\n", impathfile, im->status, im->type, im->pixelDepth, im->width, im->height);

	glEnable(GL_TEXTURE_2D);

	glGenTextures(1, &texture);

	glBindTexture(GL_TEXTURE_2D, texture);

	// Cria o objeto quadric e ativa o FILL para desenho desse objeto
	mysolid = gluNewQuadric();
	gluQuadricDrawStyle(mysolid, GLU_FILL);

	// Ativa o gerador de coordenadas de textura para o quadric
	gluQuadricTexture(mysolid, GL_TRUE);

	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); // MIPMAP
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	//gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGB, im->width, im->height, GL_RGB, GL_UNSIGNED_BYTE, im->imageData); // MIPMAP
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, im->width, im->height, 0, GL_RGB, GL_UNSIGNED_BYTE, im->imageData);

	// Destr�i a imagem
	tgaDestroy(im);
}

void Ball::draw() 
{	
	// Desenha a esfera
	if (!bagged)
	{				
		glTranslatef(pos.x, pos.y, pos.z);

		glRotatef(angx, 1, 0, 0);
		glRotatef(angy, 0, 1, 0);
		glRotatef(angz, 0, 0, 1);

		//Ilumina��o da bola
		GLfloat colorWhite[] = { 1.0f, 1.0f, 1.0f, 1.0f };
		GLfloat specReflection[] = { 0.8f, 0.8f, 0.8f, 1.0f };

		glColor4f(1.0,1.0,1.0, 1.0);

		glBindTexture(GL_TEXTURE_2D, texture);

		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, colorWhite);
		glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specReflection);
		glMateriali(GL_FRONT_AND_BACK, GL_SHININESS, 128);
	
		gluSphere(mysolid, raio, 30, 30);
	}	
}
void Ball::Update()
{
	if (!bagged)
	{
		prevPos = pos;
		pos += direction * drag * speed * 0.1f;
		if (drag > 0 && speed>0)
			drag -= 0.005f;
		else
		{
			drag = 0;
			speed = 0;
			direction = Vector3(0, 0, 0);
		}
		if (speed > 0)
		{
			Vector3 r = Vector3(0, 1, 0).Cross(direction);
			r.normalize();
			angx += r.x*speed*drag * 15;
			angy += r.y*speed*drag * 15;
			angz -= r.z*speed*drag * 15;
		}
	}	
}

void Ball::setBagg(bool b)
{
	bagged = b;
	if (b)
	{
		pos = Vector3(0, -100, 0);
		drag = 0;
		speed = 0;
		direction = Vector3(0, 0, 0);
	}
	else
	{
		pos = Vector3(0, raio, 0);
	}
}

void Ball::Hit(Vector3 _direction, float _speed)
{
	drag = 1.0f;
	speed = _speed * 0.005f;
	direction = _direction;
}