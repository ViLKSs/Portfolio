#pragma once
#include "Vector3.h"
#include "tga.h"

class Ball {
public:
	Ball();
	Ball(float r, float g, float b, float x, float y, float z, float raio, int number);
	~Ball() {  }
	void draw();
	void Update();
	void setBagg(bool b);
	void LoadBall(int number);
	void Hit(Vector3 _direction, float _speed);
	void setColor(float r, float g, float b) { red = r; green = g; blue = b; }

	// Vari�veis globais
	tgaInfo *im;
	GLuint texture;
	GLUquadric *mysolid;

	Vector3 pos = Vector3(0, 0, 0);
	Vector3 prevPos;
	Vector3 direction = Vector3(0, 0, 0);;
	float drag = 1.0f, speed = 0.0f;
	float red, green, blue;
	float angx=0, angy=0, angz=0;

	float angle = 0;
	float raio;
	int Number;
	int LastCollided;
	int LastCollidedWall;
	bool bagged;				//Bola embolsada ou n�o
};			