#define _USE_MATH_DEFINES

#include <iostream>
#include <gl/freeglut.h>
#include "Camera.h"
#include <math.h>		

namespace gameengine {

	Camera::Camera() {
		eyex = 0.0; eyey = 20.0; eyez = 5.0;
		dirx = 0.0; diry = 0.0; dirz = 0.0;
		upx = 0.0; upy = 0.0; upz = -1.0;

		anglePan = 0.0; deltaAnglePan = 0.0;
		angleTilt = 0.0; deltaAngleTilt = 0.0;

		speed = 0.05;
		deltaZoom = 0.0;
		Zoom = 5;

		std::cout << "[Camera] Create Camera" << std::endl;
	}

	Camera::~Camera() {
		std::cout << "[Camera] Destroy Camera" << std::endl;
	}

	void Camera::cameraSetPosition(double eyex, double eyey, double eyez,
		double dirx, double diry, double dirz,
		double upx, double upy, double upz)
	{
		//Defini��o da posi��o da c�mara, da dire��o para que esta olha e up da mesma
		this->eyex = eyex; this->eyey = eyey; this->eyez = eyez;
		this->dirx = dirx; this->diry = diry; this->dirz = dirz;
		this->upx = upx; this->upy = upy; this->upz = upz;

		//Defini��o dos �ngulos a usar para controlo da c�mara
		if (eyez - dirz == 0 && eyex - dirx == 0) anglePan = 0;				//Impedir divis�o 0 por 0
		else anglePan = atan2((eyex - dirz), (eyez - dirz));

		Zoom = sqrt(pow(eyex - dirx, 2) + pow(eyey - diry, 2) + pow(eyez - dirz, 2));	
	
		angleTilt = acos(fabs(eyey-diry) / Zoom);
	}

	void Camera::cameraTilt(double tilt)
	{
		deltaAngleTilt = tilt*speed;
	}

	void Camera::cameraPan(double pan) 
	{
		deltaAnglePan = pan*speed;
	}

	void Camera::cameraZoom(double zoom) 
	{
		deltaZoom =  - zoom * 2;
	}

	void Camera::cameraUpdate() 
	{
		//Update devido aos deltas
		anglePan += deltaAnglePan;
		angleTilt += deltaAngleTilt;
		Zoom += deltaZoom;

		//Clamps
		if (angleTilt > M_PI_2) angleTilt = M_PI_2;
		if (angleTilt <= 0) angleTilt = 0.01;
		if (Zoom < 2) Zoom = 2;			
		else if (Zoom > 40)	Zoom = 40;	

		eyex = dirx + Zoom * sin(angleTilt) * sin(anglePan);
		eyey = diry + Zoom * cos(angleTilt);
		eyez = dirz + Zoom * sin(angleTilt) * cos(anglePan);
		
		//Reset de deltas
		deltaAngleTilt = 0;
		deltaAnglePan = 0;
		deltaZoom = 0;

		glMatrixMode(GL_MODELVIEW);

		glLoadIdentity();

		gluLookAt(eyex, eyey, eyez,					// eye
				  dirx, diry, dirz,					// center
			      upx, upy, upz);
	}


	void Camera::cameraSwitch(double newx,double newy,double newz)
	{
		dirx = newx; diry = newy; dirz = newz;
	}

	float* Camera::returnPosition()
	{
		float aux[]{eyex, eyey, eyez};		
		return aux;
	}

	//Mudar para algumas c�maras predefinidas
	void Camera::cameraSwitch(int cam)
	{
		switch (cam)
		{
			//Centro da mesa, mesmo �ngulo
		case 1:
			dirx = 0; diry = 1; dirz = 0;
			break;

			//Top looking down
		case 2:
		default:
			dirx = 0; diry = 1; dirz = 0;
			anglePan = 0;
			angleTilt = 0;
			Zoom = 12;
			break;
		}
	}
}