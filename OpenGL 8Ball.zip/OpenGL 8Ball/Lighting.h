#pragma once

#include <gl/glut.h>

class Light {
public:
	Light(){}
	~Light() {}

	void SetLights()
	{
		if (!enabled)	glDisable(GL_LIGHTING);
		else
		{
			glEnable(GL_LIGHTING);

			if (enabled0)	glEnable(GL_LIGHT0);
			else glDisable(GL_LIGHT0);

			if (enabled1)	glEnable(GL_LIGHT1);
			else glDisable(GL_LIGHT1);

			if (enabled2)	glEnable(GL_LIGHT2);
			else glDisable(GL_LIGHT2);


			GLfloat light_ambient[] = { 0.1f, 0.1f, 0.1f, 1.0f };
			GLfloat light_diffuse[] = { 0.8f, 0.8f, 0.8f, 1.0f };
			GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
			GLfloat light_position0[] = { 0.0f, 0.0f, 15.0f, 1.0f };  //posicional 1
			GLfloat light_position1[] = { 0.0f, 0.0f, -15.0f, 1.0f }; //posicional 2
			GLfloat light_position2[] = { 0.0f, 5.0f, 0.0f, 1.0f };   //c�nica principal
			GLfloat spot_direction[] = { 0.0f, -1.0f, 0.0f };	      //direc��o da c�nica

			GLfloat global_ambient[] = { 0.2f, 0.2f, 0.2f, 1.0f };

			//Light0 posicional
			glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
			glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
			glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
			glLightfv(GL_LIGHT0, GL_POSITION, light_position0);

			//Light1 quando estiver ativa
			glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient);
			glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse);
			glLightfv(GL_LIGHT1, GL_SPECULAR, light_specular);
			glLightfv(GL_LIGHT1, GL_POSITION, light_position1);

			//Light2 quando estiver ativa
			glLightfv(GL_LIGHT2, GL_AMBIENT, light_ambient);
			glLightfv(GL_LIGHT2, GL_DIFFUSE, light_diffuse);
			glLightfv(GL_LIGHT2, GL_SPECULAR, light_specular);
			glLightfv(GL_LIGHT2, GL_POSITION, light_position2);
			glLightf(GL_LIGHT2, GL_SPOT_CUTOFF, 45.0f);
			glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, spot_direction);

			glLightModelfv(GL_LIGHT_MODEL_AMBIENT, global_ambient);
			glEnable(GL_COLOR_MATERIAL);
			glShadeModel(GL_SMOOTH);
			glEnable(GL_DEPTH_TEST);

			// Renormalize scaled normals so that lighting still works properly.
			glEnable(GL_NORMALIZE);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); //Aplicar luzes � textura
		}
	}
	void TurnLight(int n)
	{
		if(n==-1) enabled = !enabled;
		else if (n == 0) enabled0 = !enabled0;
		else if (n == 1) enabled1 = !enabled1;
		else if (n == 2) enabled2 = !enabled2;
	}

private:
	bool enabled = true;
	bool enabled0 = true;
	bool enabled1 = true;
	bool enabled2 = true;

};