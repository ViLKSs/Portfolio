#include "Game1.h"

int main(int argc, char **argv) {
	srand(time(NULL));
	Game1 game;
	int wId = game.gameAddMainWindow(0, 0, 1600, 1000, "Main Window 1");
	game.gameCameraSetPosition(wId, -8, 8, 0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0);
	L = Light();
	game.gameSetWindowCallbacks(wId);
	int swId = game.gameAddSubWindow(wId, 10, 10, 400, 400, "Sub Window 1");
	game.gameSetSubWindowCallbacks(wId,swId);
	game.gameCameraSetPositionSub(wId,swId, 0, 15, 0, 0, 0, 0, 0, 0, -1);			

	Game::gameSetTimerFPS(100);
	// Inicia o lan�amento de eventos de display, para cada janela, de acordo com o FPS definido
	Game::gameTimerRun(wId);
	Game::gameTimerRun(swId);
	// Entra no ciclo de gest�o da aplica��o por eventos
	Game::gameRun();

	return 0;
}