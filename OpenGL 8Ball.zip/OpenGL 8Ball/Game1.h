#pragma once
#include "Game.h"
#include "Ball.h"
#include "BallCollision.h"
#include "Wall.h"
#include "stdlib.h"
#include "Hole.h"
#include "SkyBox.h"
#include "Lighting.h"
#include <algorithm>
#include <random>
#include <chrono>  
#include <time.h>  

#define BallNumber 16
#define WallNumber 9
#define HoleNumber 4

using namespace gameengine;
using namespace std;

BallCollision bc;
Ball balls[BallNumber];

static float angle = 0.0;
static float red = 1.0, blue = 1.0, green = 1.0;

Vector3 mousePos1(0,0,0), mousePos2(0,0,0), constantMousePos(0,0,0);
Vector3 cameraPos;
int camera = 0;			//Camara a ser usada

Wall wall[WallNumber];

Hole holes[HoleNumber];

bool left_button_state = false;
bool right_button_state = false;
int Turn = 0;

bool menu = true;
int width = 800;
int height = 600;
int selected = 1;

float base_time = 0;
float fps = 0;
int frames = 0;

SkyBox sk;
Light L;

void DrawTextOnScreen(const char *text, int length, int x, int y);
void DrawHud(void);

class Game1 : public Game
{
public:
	void gameSetWindowCallbacks(int windowID);
	void gameSetSubWindowCallbacks(int ParentId, int windowID);
};

void createGameCharacters()
{
	balls[0] = Ball(1.0f, 1.0f, 1.0f, -4.2f, 0, 0.25, 0.2f, 0);
	float raio = 0.20f;
	int ballNumber = 2;
	float zPos = 0;
	for (int i = 1; i < 6; i++)
	{
		if (i == 1)
		{
			balls[1] = Ball(0.0f, 0.0f, 1.0f, i * 2.1f*raio, 0, 0.25f, 0.2f, 1);
			zPos = 0.25f;
		}
		else
		{
			for (int j = 0; j < i; j++)
			{
				if (ballNumber % 2)
					balls[ballNumber] = Ball(0.0, 0.0, 1.0, i * 2.1f*raio, 0, j * 2.1f*raio + zPos, raio, ballNumber);
				else if (!(ballNumber % 2))
					balls[ballNumber] = Ball(1.0, 0.0, 0.0, i * 2.1f*raio, 0, j * 2.1f*raio + zPos, raio, ballNumber);
				ballNumber++;
			}
		}
		zPos -= 0.25f;
	}

	wall[0] = Wall(7.6, 0.7, 1, Vector3(0, 0, 5), 1, 2);
	wall[1] = Wall(1, 0.7, 7.6, Vector3(5, 0, 0),  2, 2);
	wall[2] = Wall(7.6, 0.7, 1, Vector3(0, 0, -5), 3, 2);
	wall[3] = Wall(1, 0.7, 7.6, Vector3(-5, 0, 0),  4, 2);
	wall[4] = Wall(11, 0.7, 0.3, Vector3(0, 0, -5.5), 5, 2);
	wall[5] = Wall(11, 0.7, 0.3, Vector3(0, 0, 5.5), 6, 2);
	wall[6] = Wall(0.3, 0.7, 11, Vector3(5.5, 0, 0), 7 ,2);
	wall[7] = Wall(0.3, 0.7, 11, Vector3(-5.5, 0, 0), 8,2);
	wall[8] = Wall(11, 0.7, 11, Vector3(0, -0.35, 0), 9, 1);

	holes[0].setProperties(1, 0.8, 1, Vector3(3.8 + 1, 0, 5), 0.8, 0.4, 0.0, 1);
	holes[1].setProperties(1, 0.8, 1, Vector3(-3.8 - 1, 0, 5), 0.8, 0.4, 0.0, 1);
	holes[2].setProperties(1, 0.8, 1, Vector3(5, 0, -3.8 - 1), 0.8, 0.4, 0.0, 1);
	holes[3].setProperties(1, 0.8, 1, Vector3(-5, 0, -3.8 - 1), 0.8, 0.4, 0.0, 1);

	Vector3 p = balls[8].pos;
	balls[8].pos = balls[5].pos;
	balls[5].pos = p;

	//Randomizar posi��o inicial das bolas
	for (int i = 1; i < BallNumber; i++)
	{
		int v1 = rand() % (ballNumber - 1) + 1;
		if (balls[i].Number != 8 && balls[v1].Number != 8)
		{
			Vector3 pos = balls[i].pos;
			balls[i].pos = balls[v1].pos;
			balls[v1].pos = pos;
		}
	}

	sk = SkyBox(100,100,100,Vector3(0,0,0), 1, 2);
}
	

bool AreAllBallsStoped()
{
	for (int i = 0; i < BallNumber; i++)
		if (balls[i].speed > 0)
			return false;
	return true;
}

void drawSceneGame1(void) {
	L.SetLights();

	MainWindow *currentWindow = (MainWindow *)glutGetWindowData();
	glutSetWindow(currentWindow->windowId);

	cameraPos = Vector3(currentWindow->camera.returnPosition()[0],
		balls[0].raio, currentWindow->camera.returnPosition()[2]);
	glEnable(GL_TEXTURE_2D);
	for (int i = 0; i < BallNumber; i++)
	{
		balls[i].Update();
		bc.BallUpdateCollision(balls[i], balls, BallNumber);
		for (int j = 0; j < WallNumber; j++)
		{			
			bc.BallUpdateCollision(balls[i], wall[j]);		
		}
		for (int k = 0; k < HoleNumber; k++)
		{
			bc.BallUpdateCollisionHole(balls[i], holes[k], Turn);
		}		
		glPushMatrix();					
		balls[i].draw();
		glPopMatrix();	
	}			
	for (int i = 0; i < WallNumber; i++)
	{
		wall[i].Draw();
	}	
	sk.Draw();
	glDisable(GL_TEXTURE_2D);
	if (AreAllBallsStoped())
	{
		if (camera == 0)
		{
			currentWindow->camera.cameraSwitch(balls[0].pos.x, balls[0].pos.y, balls[0].pos.z);
		}

		if (left_button_state)
		{
			glPushMatrix();
			glDisable(GL_LIGHTING);

			Vector3 direction = (balls[0].pos - cameraPos).normalize() * (mousePos1 - constantMousePos).length() * 0.01f;
			if (bc.IsBallGoingToCollide(balls[0].pos, balls[0].pos + direction, balls, BallNumber))
				glColor3f(1.0f, 0.0f, 0.0f);
			else glColor3f(1.0f, 1.0f, 1.0f);

			glBegin(GL_LINES);
			glVertex3f(balls[0].pos.x, balls[0].raio, balls[0].pos.z);
			glVertex3f(balls[0].pos.x + direction.x, balls[0].raio, balls[0].pos.z + direction.z);
			glEnd();

			glEnable(GL_LIGHTING);
			glPopMatrix();
		}
	}


	for (int k = 0; k < HoleNumber; k++)
	{
		holes[k].Draw();
	}

	float time = glutGet(GLUT_ELAPSED_TIME);
	if ((time - base_time) > 1000.0)
	{
		fps = frames * 1000.0 / (time - base_time);
		base_time = time;
		frames = 0;
	}

	glColor3f(1, 1, 1);
	std::string textp;
	textp = std::to_string(fps);
	DrawTextOnScreen(textp.data(), textp.size(), currentWindow->screenWidth - 100, currentWindow->screenHeight - 100);
	frames++;	

	DrawHud();
}

void DrawHud()
{
	glDisable(GL_LIGHTING);
	MainWindow *currentWindow = (MainWindow *)glutGetWindowData();
	glutSetWindow(currentWindow->windowId);

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0.0, currentWindow->screenWidth, currentWindow->screenHeight, 0.0, -1.0, 10.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glDisable(GL_CULL_FACE);


	glClear(GL_DEPTH_BUFFER_BIT);


	for (int i = 1; i < BallNumber; i++)
	{
		if (!balls[i].bagged)
		{
			glColor3f(1, 0, 0);
		}
		else
		{
			glColor3f(0, 1, 0);
		}		
		std::string textp;
		textp = std::to_string(i);
		DrawTextOnScreen(textp.data(), textp.size(), (float)currentWindow->screenWidth/4.0f + i * (20), 10);
	}
	std::string text;
	text = "TURN : " + std::to_string(Turn);
	DrawTextOnScreen(text.data(), text.size(), (float)currentWindow->screenWidth / 2.0f, currentWindow->screenHeight - 20);

	int px = 50, py = currentWindow->screenHeight - 50;

	// Making sure we can render 3d again
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glEnable(GL_LIGHTING);

}

void drawSceneGame2(void) {

	glEnable(GL_TEXTURE_2D);
	for (int i = 0; i < BallNumber; i++)
	{		
		glPushMatrix();
		balls[i].draw();
		glPopMatrix();	
	}	

	for (int i = 0; i < WallNumber; i++)
	{
		wall[i].Draw();
	}
	glDisable(GL_TEXTURE_2D);
	if (AreAllBallsStoped() && left_button_state)
	{
		glPushMatrix();
		glDisable(GL_LIGHTING);

		Vector3 direction = (balls[0].pos - cameraPos).normalize() * (mousePos1 - constantMousePos).length() * 0.01f;
		if (bc.IsBallGoingToCollide(balls[0].pos, balls[0].pos + direction, balls, BallNumber))
			glColor3f(1.0f, 0.0f, 0.0f);
		else glColor3f(1.0f, 1.0f, 1.0f);

		glBegin(GL_LINES);
		glVertex3f(balls[0].pos.x, balls[0].raio, balls[0].pos.z);
		glVertex3f(balls[0].pos.x + direction.x, balls[0].raio, balls[0].pos.z + direction.z);
		glEnd();

		glEnable(GL_LIGHTING);
		glPopMatrix();

	}

	L.SetLights();

	for (int k = 0; k < HoleNumber; k++)
	{
		holes[k].Draw();
	}
}

void DrawTextOnScreen(const char *text, int length, int x, int y)
{
	MainWindow *currentWindow = (MainWindow *)glutGetWindowData();
	glutSetWindow(currentWindow->windowId);

	glMatrixMode(GL_PROJECTION); // mudar para matriz de proje�ao
	double matrix[16];
	glGetDoublev(GL_PROJECTION_MATRIX, matrix);// obter valores da matriz de proje�ao
	glLoadIdentity(); // reset para matriz de identidade
	glOrtho(0, currentWindow->screenWidth, 0, currentWindow->screenHeight, -5, 5);//perspectiva
	glMatrixMode(GL_MODELVIEW);//mudar para modelview matrix
	glLoadIdentity();
	glPushMatrix();
	glLoadIdentity();
	glRasterPos2i(x, y); // raster position em 2d
	for (int i = 0; i < length; i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_9_BY_15, (int)text[i]);
	}
	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glLoadMatrixd(matrix);
	glMatrixMode(GL_MODELVIEW);
}

void DrawButtonPlay(Vector3 position, float r, float g, float b)
{
	glPushMatrix();
	float l1 = 3;
	float l2 = 1;
	float l3 = 1;
	glTranslatef(position.x, position.y, position.z);
	glBegin(GL_QUADS);
	glColor3f(r, g, b);
	glVertex3f(-l1, l2, l3);
	glVertex3f(l1, l2, l3);
	glVertex3f(l1, l2, -l3);
	glVertex3f(-l1, l2, -l3);
	glEnd();
	
	glPopMatrix();
}

void DrawButtonExit(Vector3 position, float r, float g, float b)
{
	glPushMatrix();
	float l1 = 3;
	float l2 = 1;
	float l3 = 1;
	glTranslatef(position.x, position.y, position.z);
	glBegin(GL_QUADS);
	glColor3f(r, g, b);
	glVertex3f(-l1, l2, l3);
	glVertex3f(l1, l2, l3);
	glVertex3f(l1, l2, -l3);
	glVertex3f(-l1, l2, -l3);
	glEnd();
	
	glFlush();
}

void changeWindiwCallBacks(int windId)
{
	glutDisplayFunc([](void) {

		MainWindow *currentWindow = (MainWindow *)glutGetWindowData();
		glutSetWindow(currentWindow->windowId);
		if (currentWindow->windowId == 1)
			currentWindow->windowId = currentWindow->windowId;
		glClearColor(0.0, 0.0, 0.0, 0.0);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		currentWindow->camera.cameraUpdate();
		drawSceneGame1();

		glutSwapBuffers();
		glFlush();
	});

	glutReshapeFunc([](int w, int h) {
		MainWindow *currentWindow = (MainWindow *)glutGetWindowData();
		glutSetWindow(currentWindow->windowId);

		// Previne a divis�o por zero
		if (h == 0) h = 1;
		double ratio = double(w) / double(h);

		// O viewport ocupar� toda a janela
		glViewport(0, 0, w, h);

		// Efetua o reset do sistema de coordenadas
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();

		// Aplica a perspectiva
		gluPerspective(45.0, ratio, 0.1, 300.0);

		// Altera o sistema de coordenadas, para GL_MODELVIEW
		glMatrixMode(GL_MODELVIEW);
	});

	glutKeyboardFunc([](unsigned char key, int x, int y) {
		MainWindow *currentWindow = (MainWindow *)glutGetWindowData();
		glutSetWindow(currentWindow->windowId);

		switch (key)
		{
		case 27:
			glutDestroyWindow(currentWindow->windowId);
			break;
		default:
			break;
		}
	});

	glutKeyboardUpFunc([](unsigned char key, int x, int y)
	{

	});

	glutSpecialFunc([](int key, int x, int y) {

		MainWindow *currentWindow = (MainWindow *)glutGetWindowData();

		switch (key)
		{
			//Windowed
		case  GLUT_KEY_F4:
			glutSetWindow(currentWindow->windowId);
			glutReshapeWindow(currentWindow->screenWidth, currentWindow->screenHeight);
			glutPositionWindow(currentWindow->x, currentWindow->y);
			break;

			//FullScreen
		case  GLUT_KEY_F5:
			glutSetWindow(currentWindow->windowId);
			glutFullScreen();
			break;

			//Centro da mesa, mesmo �ngulo
		case GLUT_KEY_F2:
			currentWindow->camera.cameraSwitch(1);
			camera = 1;
			break;

			//Top looking down
		case GLUT_KEY_F3:
			currentWindow->camera.cameraSwitch(2);
			break;

			//Ilumina��o
		case GLUT_KEY_F6:
			L.TurnLight(-1);
			break;
		case GLUT_KEY_F7:
			L.TurnLight(2);
			break;
		case GLUT_KEY_F8:
			L.TurnLight(1);
			break;
		case GLUT_KEY_F9:
			L.TurnLight(0);
			break;

			//Centrado na bola
		case GLUT_KEY_F1:
		default:
			currentWindow->camera.cameraSwitch(balls[0].pos.x, balls[0].pos.y, balls[0].pos.z);
			camera = 0;
			break;
		}
	});

	glutSpecialUpFunc([](int key, int x, int y) {

	});

	glutMouseFunc([](int button, int state, int x, int y) {
		//Bot�o Esquerdo
		if (AreAllBallsStoped())				//Bolas paradas
		{
			if (button == GLUT_LEFT_BUTTON && !left_button_state)
			{
				mousePos1 = Vector3(x, 0, y);
				constantMousePos = mousePos1;
				left_button_state = true;
			}
			else if (button == GLUT_LEFT_BUTTON && left_button_state)
			{
				mousePos2 = Vector3(x, 0, y);
				if (mousePos1 != mousePos2)
				{
					Vector3 direction = (balls[0].pos - cameraPos);
					float lenght = (mousePos1 - mousePos2).length();
					balls[0].Hit(direction.normalize(), lenght);
					constantMousePos = mousePos1;
					Turn++;
				}
				left_button_state = false;
			}
		}

		//Bot�o Direito
		if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
		{
			right_button_state = true;
			mousePos1 = Vector3(x, 0, y);
		}

		else if (button == GLUT_RIGHT_BUTTON && state == GLUT_UP) right_button_state = false;

	});

	glutMotionFunc([](int x, int y) {
		constantMousePos = Vector3(x, 0, y);
		if (left_button_state) camera = 0;
		if (right_button_state)
		{
			if (constantMousePos.z != mousePos1.z && fabs(constantMousePos.z - mousePos1.z) > 5)
			{
				MainWindow *currentWindow = (MainWindow *)glutGetWindowData();
				currentWindow->camera.cameraTilt((mousePos1.z - constantMousePos.z) / fabs(mousePos1.z - constantMousePos.z));

				mousePos1.z = constantMousePos.z;
			}

			if (constantMousePos.x != mousePos1.x && fabs(constantMousePos.x - mousePos1.x) > 5)
			{
				MainWindow *currentWindow = (MainWindow *)glutGetWindowData();
				currentWindow->camera.cameraPan((mousePos1.x - constantMousePos.x) / fabs(mousePos1.x - constantMousePos.x));

				mousePos1.x = constantMousePos.x;
			}
		}
	});

	glutPassiveMotionFunc([](int x, int y) {

	});

	glutEntryFunc([](int state) {

	});

	glutMouseWheelFunc([](int wheel, int direction, int x, int y) {
		MainWindow *currentWindow = (MainWindow *)glutGetWindowData();
		currentWindow->camera.cameraZoom(direction);
	});

	//LoadTexturas	
	for (int i = 0; i < BallNumber; i++) 
		balls[i].LoadBall(i);	

	for (int i = 0; i < WallNumber; i++)
	{
		wall[i].LoadWall();
	}
	sk.LoadWall();
}

void Game1::gameSetWindowCallbacks(int windowID) {
	for (int i = 0; i < int(gameMainWindows.size()); i++) {
		if (gameMainWindows[i].windowId == windowID) {
			glutSetWindowData((void *)&gameMainWindows[i]);
			break;
		}
	}
		
		glutDisplayFunc([](void) {

			MainWindow *currentWindow = (MainWindow *)glutGetWindowData();
			glutSetWindow(currentWindow->windowId);
			if (currentWindow->windowId == 1)
				currentWindow->windowId = currentWindow->windowId;
			glClearColor(0.0, 0.0, 0.0, 0.0);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

			gluLookAt(0, 20, 0, 0, 0, 0, 0, 0, -1);

			if (selected == 1) {
				DrawButtonPlay(Vector3(0,0,-4),0, 1, 1);
				DrawButtonExit(Vector3(0,0,0),1, 1, 1);
			}
			else if (selected == 2) {
				DrawButtonPlay(Vector3(0, 0, -4),1, 1, 1);
				DrawButtonExit(Vector3(0, 0, 0),0, 1, 1);
			}

			glColor3f(0, 0, 0);
			std::string textp, texte;
			textp = "PLAY GAME";
			DrawTextOnScreen(textp.data(), textp.size(), currentWindow->screenWidth / 2.2, currentWindow->screenHeight / 1.35);

			glColor3f(0, 0, 0);
			texte = "EXIT";
			DrawTextOnScreen(texte.data(), texte.size(), currentWindow->screenWidth / 2.2, currentWindow->screenHeight / 2);

			glutSwapBuffers();
		});

		glutSpecialFunc([](int key, int x, int y) {

			switch (key)
			{
			case GLUT_KEY_UP:
				if (selected >1 && selected <= 2)
					selected--;
				break;
			case GLUT_KEY_DOWN:
				if (selected >= 1 && selected < 2)
					selected++;
				break;
			}

			glutPostRedisplay();
		});

		glutReshapeFunc([](int w, int h) {
			MainWindow *currentWindow = (MainWindow *)glutGetWindowData();
			glutSetWindow(currentWindow->windowId);

			// Previne a divis�o por zero
			if (h == 0) h = 1;
			double ratio = 1.0 * double(w) / double(h);

			// O viewport ocupar� toda a janela
			glViewport(0, 0, w, h);

			width = w;
			height = h;

			// Efetua o reset do sistema de coordenadas
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();

			// Aplica a perspectiva
			gluPerspective(45.0, ratio, 0.1, 300.0);

			// Altera o sistema de coordenadas, para GL_MODELVIEW
			glMatrixMode(GL_MODELVIEW);
		});
		glutKeyboardUpFunc([](unsigned char key, int x, int y)
		{
			MainWindow *currentWindow = (MainWindow *)glutGetWindowData();
			glutSetWindow(currentWindow->windowId);
			if (key == 13 && selected == 1)
			{
				//Entrar no jogo
				changeWindiwCallBacks(currentWindow->windowId);
				std::cout << "Entrar no jogo" << "\n";
			}
			if (key == 13 && selected == 2)
			{
				exit(0);
			}
		});
	
}


void Game1::gameSetSubWindowCallbacks(int ParentId,int windowID) {
	for (int j = 0; j < int(gameMainWindows.size()); j++) {
		if (gameMainWindows[j].windowId == ParentId) {
			for (int i = 0; i < int(gameMainWindows[j].gameSubWindows.size()); i++) {
				if (gameMainWindows[j].gameSubWindows[i].subWindowId == windowID) {
					glutSetWindowData((void *)&gameMainWindows[j].gameSubWindows[i]);
					break;
				}
			}
		}
	}	
	createGameCharacters();//Load das bolas

	glutDisplayFunc([](void) {

		SubWindow *currentWindow = (SubWindow *)glutGetWindowData();
		glutSetWindow(currentWindow->subWindowId);

		if (currentWindow->subWindowId == 1)
			currentWindow->subWindowId = currentWindow->subWindowId;
		glClearColor(0.0, 0.0, 0.0, 0.0);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

		currentWindow->camera.cameraUpdate();
		drawSceneGame2();

		glutSwapBuffers();
	});

	glutSpecialFunc([](int key, int x, int y) {

		SubWindow *currentWindow = (SubWindow *)glutGetWindowData();

		switch (key)
		{
			//Windowed
		case  GLUT_KEY_F4:
			glutSetWindow(currentWindow->subWindowId);
			glutReshapeWindow(currentWindow->screenWidth, currentWindow->screenHeight);
			glutPositionWindow(currentWindow->x, currentWindow->y);
			break;
			//FullScreen
		case  GLUT_KEY_F5:
			glutSetWindow(currentWindow->subWindowId);
			glutFullScreen();
			//Centro da mesa, mesmo �ngulo
		case GLUT_KEY_F2:
			currentWindow->camera.cameraSwitch(1);
			camera = 1;
			break;

			//Top looking down
		case GLUT_KEY_F3:
			currentWindow->camera.cameraSwitch(2);
			break;

			//Centrado na bola
		case GLUT_KEY_F1:
		default:
			currentWindow->camera.cameraSwitch(balls[0].pos.x, balls[0].pos.y, balls[0].pos.z);
			camera = 0;
			break;
		}
	});

	glutReshapeFunc([](int w, int h) {
		SubWindow *currentWindow = (SubWindow *)glutGetWindowData();
		glutSetWindow(currentWindow->subWindowId);

		// Previne a divis�o por zero
		if (h == 0) h = 1;
		double ratio = 1.0 * double(w) / double(h);

		// O viewport ocupar� toda a janela
		glViewport(0, 0, w, h);

		// Efetua o reset do sistema de coordenadas
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();

		// Aplica a perspectiva
		gluPerspective(45.0, ratio, 0.1, 300.0);

		// Altera o sistema de coordenadas, para GL_MODELVIEW
		glMatrixMode(GL_MODELVIEW);
	});

	glutMouseWheelFunc([](int wheel, int direction, int x, int y) {
		SubWindow *currentWindow = (SubWindow *)glutGetWindowData();
		currentWindow->camera.cameraZoom(direction);
	});
}