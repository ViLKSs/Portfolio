#pragma once

#include <cmath>
class Vector3 {

public:
	float x, y, z;

	Vector3(float x = 0, float y = 0, float z = 0) : x(x), y(y), z(z) {}

	Vector3(Vector3& vector) : x(vector.x), y(vector.y), z(vector.z) {}

	~Vector3() {}

	// = operator
	Vector3 operator=(Vector3& vector) {
		if (&vector != this) {
			x = vector.x;
			y = vector.y;
			z = vector.z;
		}
		return *this;
	}

	// + operator
	Vector3 operator+(Vector3 &v) {
		return Vector3(x + v.x, y + v.y, z + v.z);
	}

	// += operator
	Vector3 operator+=(Vector3 &v) {
		x += v.x; y += v.y; z += v.z;
		return *this;
	}

	// - operator
	Vector3 operator-(Vector3 &v) {
		return Vector3(x - v.x, y - v.y, z - v.z);
	}

	// -= operator
	Vector3 operator-=(Vector3 &v) {
		x -= v.x; y -= v.y; z -= v.z;
		return *this;
	}

	// == operator
	bool operator==(Vector3 &v) {
		return x == v.x && y == v.y && z == v.z;
	}

	// != operator
	bool operator!=(Vector3 &v) {
		return !(*this == v);
	}

	// * operator
	Vector3 operator*(float f) {
		return Vector3(f*x, f*y, f*z);
	}

	// *= operator
	Vector3 operator*=(float f) {
		x *= f; y *= f; z *= f;
		return *this;
	}

	// / operator
	Vector3 operator/(float f) {
		if (0 != 0)
		{
			float inv = 1.f / f;
			return Vector3(x * inv, y * inv, z * inv);
		}
		else return *this;
	}

	// /= operator
	Vector3 operator/=(float f) {
		if (0 != 0)
		{
			float inv = 1.f / f;
			x *= inv; y *= inv; z *= inv;
			return *this;
		}
		else return *this;
	}

	// - operator
	Vector3 operator-() const {
		return Vector3(-x, -y, -z);
	}

	// Normalize
	Vector3 normalize() {
		float l = length();
		return (l == 0.0) ? Vector3(0.0, 0.0, 0.0) : Vector3(x / l, y / l, z / l);
	}

	//squared length
	float lengthSquared() const { return x*x + y*y + z*z; }

	// length
	float length() const { return sqrt(lengthSquared()); }

	Vector3  Cross(const Vector3& vec2)
	{
		return Vector3(
			y * vec2.z - z * vec2.y,
			z * vec2.x - x * vec2.z,
			x * vec2.y - y * vec2.x);
	}
};