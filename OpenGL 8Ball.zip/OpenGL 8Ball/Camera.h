#pragma once

namespace gameengine {

	class Camera {
	public:
		Camera();
		~Camera();
		void cameraSetPosition(double eyex, double eyey, double eyez,
			double dirx, double diry, double dirz,
			double upx, double upy, double upz);
		void cameraTilt(double tilt);
		void cameraPan(double pan);
		void cameraZoom(double zoom);
		void cameraUpdate();
		void cameraSwitch(double newx, double newy, double newz);
		void cameraSwitch(int cam);
		float* returnPosition();

	private:
		double eyex, eyey, eyez;	// Posi��o da c�mara (centro-de-massa)
		double dirx, diry, dirz;	// Vector do sentido que a camara est� a olhar
		double upx, upy, upz;		// Vector que indica a parte superior da c�mara

		double anglePan, angleTilt;	// �ngulos de Pan e Tilt
		double deltaAnglePan, deltaAngleTilt;

		double Zoom, deltaZoom;		// Para aproximar na dire�ao da camara
		double speed;				// Constante de velocidade de deslocamento
	};
}