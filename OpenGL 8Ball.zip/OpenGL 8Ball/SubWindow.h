#pragma once
#pragma once

#include <iostream>
#include <sstream>
#include <string>
#include "Camera.h"

namespace gameengine {

	class SubWindow
	{
	public:
		SubWindow(int ParentId, int x, int y, int width, int height, std::string subWindowName = "");;
		~SubWindow();

		int subWindowId;
		Camera camera;
		int x, y, screenWidth, screenHeight;
	private:
		static int countSubWindows;
		std::string subWindowName;
	};
}