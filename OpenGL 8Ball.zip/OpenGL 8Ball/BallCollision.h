#pragma once
#include "Ball.h"
#include "Wall.h"
#include "Hole.h"
#include <iostream>
using namespace std;
using namespace gameengine;

class BallCollision
{
public:
	BallCollision();
	void BallUpdateCollision(Ball &unique, Ball *rest, int sizeRest);
	void BallUpdateCollision(Ball &ball, Wall wall);
	void BallUpdateCollisionHole(Ball &ball, Hole hole, int &turn);
	bool IsBallGoingToCollide(Vector3 ballPos, Vector3 directionPos, Ball *rest, int sizeRest);
	~BallCollision();

private:

};

BallCollision::BallCollision()
{
}

void BallCollision::BallUpdateCollision(Ball &unique, Ball *rest, int sizeRest)
{
	if(!unique.bagged)
	for (int i = 0; i < sizeRest; i++)
	{
		if (!rest[i].bagged)
		{
			if ((unique.pos != rest[i].pos) && ((unique.pos - rest[i].pos).length() <= unique.raio + rest[i].raio)
				&& unique.LastCollided != rest[i].Number && unique.Number != rest[i].LastCollided)
			{
				unique.LastCollided = rest[i].Number;
				rest[i].LastCollided = unique.Number;

				rest[i].direction = ((rest[i].direction + (rest[i].pos - unique.pos).normalize()).normalize());
				rest[i].drag = unique.drag * 1.2;
				rest[i].speed = unique.speed * 0.5f;
				unique.speed *= 0.5f;
				unique.direction = (unique.direction - rest[i].direction).normalize();
			}
			if (unique.LastCollided == rest[i].Number && !((unique.pos - rest[i].pos).length() < unique.raio + rest[i].raio) && (unique.pos != rest[i].pos))
			{
				unique.LastCollided = -1;
				rest[i].LastCollided = -1;
			}
		}
	}
}

void BallCollision::BallUpdateCollision(Ball &ball, Wall wall)
{
	if (!ball.bagged)
	{
		if ((wall.position.x + wall.width / 2.0f >= ball.pos.x - ball.raio&& wall.position.x - wall.width / 2.0f <= ball.pos.x + ball.raio)
			&& (wall.position.z + wall.other / 2.0f >= ball.pos.z - ball.raio && wall.position.z - wall.other / 2.0f <= ball.pos.z + ball.raio))
		{
			if ((wall.position.x + wall.width / 2.0f >= ball.prevPos.x - ball.raio && wall.position.x - wall.width / 2.0f <= ball.prevPos.x + ball.raio)
				&& (wall.position.z + wall.other / 2.0f < ball.prevPos.z - ball.raio || wall.position.z - wall.other / 2.0f > ball.prevPos.z + ball.raio))
			{
				ball.direction.z = -ball.direction.z;
			}
			else if ((wall.position.x + wall.width / 2.0f < ball.prevPos.x - ball.raio || wall.position.x - wall.width / 2.0f > ball.prevPos.x + ball.raio)
				&& (wall.position.z + wall.other / 2.0f >= ball.prevPos.z - ball.raio && wall.position.z - wall.other / 2.0f <= ball.prevPos.z + ball.raio))
			{
				ball.direction.x = -ball.direction.x;
			}
		}
	}
}

bool BallCollision::IsBallGoingToCollide(Vector3 ballPos, Vector3 directionPos, Ball *rest, int sizeRest)
{
	for (int i = 1; i < sizeRest; i++)
	{
		Vector3 vpc = ballPos - rest[i].pos;

		float A = (rest[i].pos - ballPos).length();
		float B = (rest[i].pos - directionPos).length();
		float C = (directionPos - ballPos).length();

		float sp = (A + B + C) * 0.5f;

		float area = (float)sqrt(sp * (sp - A) * (sp - B) *(sp - C));

		float d = 2 * area / C;

		if (d <= rest[i].raio)
		{
			return true;
		}
	}
	return false;
}

void BallCollision::BallUpdateCollisionHole(Ball &ball, Hole hole, int &turn)
{
	if (!ball.bagged)
	{
		if ((hole.position.x + hole.width / 2.0f >= ball.pos.x && hole.position.x - hole.width / 2.0f <= ball.pos.x)
			&& (hole.position.z + hole.other / 2.0f >= ball.pos.z && hole.position.z - hole.other / 2.0f <= ball.pos.z)
			&& (hole.position.y + hole.height / 2.0f >= ball.pos.y && hole.position.y - hole.height / 2.0f <= ball.pos.y))
		{
			if (ball.Number == 0)
			{
				ball.pos = Vector3(0, ball.raio, 0);
				ball.speed = 0;
				ball.drag = 0;
				ball.direction = Vector3(0, 0, 0);
				turn++;
			}
			else
			{
				ball.setBagg(true);
			}
		}
	}
}


BallCollision::~BallCollision()
{
}