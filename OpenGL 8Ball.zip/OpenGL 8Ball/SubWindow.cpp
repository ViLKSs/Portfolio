#include <iostream>
#include <gl/freeglut.h>
#include "SubWindow.h"

namespace gameengine {

	int SubWindow::countSubWindows = 1;

	SubWindow::SubWindow(int ParentId, int x, int y, int width, int height, std::string subWindowName) : x(x), y(x), screenWidth(width), screenHeight(height), subWindowName(subWindowName) {
		if (subWindowName.empty()) {
			std::ostringstream stringStream;
			stringStream << "Game Window #" << countSubWindows++;
			subWindowName = stringStream.str();
		}

		glutInitDisplayMode(GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGBA);
		subWindowId = glutCreateSubWindow(ParentId,x,y,screenWidth,screenHeight);

		glEnable(GL_DEPTH_TEST);
		glEnable(GL_CULL_FACE);

		glShadeModel(GL_SMOOTH);

		std::cout << "[SubWindow] Create Sub Window " << subWindowId << std::endl;
	}

	SubWindow::~SubWindow() {
		std::cout << "[SubWindow] Destroy Sub Window " << subWindowId << std::endl;
	}
}